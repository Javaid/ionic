import { Component, OnInit } from "@angular/core";
import { Router, RouterEvent } from "@angular/router";
import { MenuController } from "@ionic/angular";

@Component({
  selector: "app-menu",
  templateUrl: "./menu.page.html",
  styleUrls: ["./menu.page.scss"]
})
export class MenuPage implements OnInit {
  pages = [
    {
      title: "Profile",
      url: "/home/profile"
    },
    {
      title: "Change Password",
      url: "/home/settings/username"
    },
    {
      title: "change username",
      url: "/home/settings/username"
    },
    {
      title: "change email",
      url: "/home/settings/username"
    },
    {
      title: "contact us",
      url: "/home/settings/contactus"
    },
    {
      title: "team credit",
      url: "/home/settings/team"
    },
    {
      title: "citizen manual",
      url: "/home/settings/manual"
    },
    {
      title: " privacy policy",
      url: "/home/settings/privacy"
    },
    {
      title: "logout",
      url: "/login"
    }
  ];
  selectedPath = "";
  constructor(private router: Router, private mnuCtrl: MenuController) {
    this.router.events.subscribe((event: RouterEvent) => {
      this.selectedPath = event.url;
    });
  }
 
  ngOnInit() {}
}
